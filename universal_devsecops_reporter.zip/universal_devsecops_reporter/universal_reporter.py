#!/usr/bin/env python3
"""
Universal DevSecOps Reporter
Автоматически собирает и анализирует отчеты проверок безопасности и качества кода.
"""

import os
import argparse
import yaml
from typing import List, Dict, Any
from glob import glob

from parsers.sonarqube_parser import SonarQubeParser
from parsers.zap_parser import ZAPParser
from parsers.bandit_parser import BanditParser
from parsers.flake8_parser import Flake8Parser
from utils.html_generator import HTMLGenerator
from utils.notifier import Notifier

class UniversalReporter:
    """Основной класс универсального репортера."""
    
    def __init__(self, config_path: str = "config/tool_config.yaml"):
        self.config = self._load_config(config_path)
        self.all_issues = []
        self.summaries = {}
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Загружает конфигурацию из YAML файла."""
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            print(f"Config file {config_path} not found. Using defaults.")
            return {}
    
    def discover_reports(self, reports_dir: str = ".") -> Dict[str, List[str]]:
        """Обнаруживает отчеты в указанной директории."""
        report_patterns = {
            'sonarqube': ['**/sonar-report.json', '**/sonarqube.json'],
            'zap': ['**/zap-report.json', '**/owasp-zap-report.json'],
            'bandit': ['**/bandit-report.json'],
            'flake8': ['**/flake8-report.json', '**/flake8.txt'],
            'jacoco': ['**/jacoco.xml', '**/jacocoReport.xml']
        }
        
        found_reports = {}
        for tool, patterns in report_patterns.items():
            found_reports[tool] = []
            for pattern in patterns:
                found_reports[tool].extend(glob(os.path.join(reports_dir, pattern), recursive=True))
        
        return found_reports
    
    def parse_reports(self, reports_dict: Dict[str, List[str]]):
        """Парсит все обнаруженные отчеты."""
        parser_classes = {
            'sonarqube': SonarQubeParser,
            'zap': ZAPParser,
            'bandit': BanditParser,
            'flake8': Flake8Parser,
            # 'jacoco': JacocoParser  # Можно добавить позже
        }
        
        for tool, report_files in reports_dict.items():
            if tool not in parser_classes or not report_files:
                continue
                
            parser_class = parser_classes[tool]
            for report_file in report_files:
                try:
                    print(f"Parsing {report_file} with {tool} parser...")
                    parser = parser_class(report_file)
                    parser.parse()
                    
                    # Собираем issues
                    self.all_issues.extend(parser.get_issues())
                    
                    # Собираем сводки
                    tool_name = f"{tool}_{os.path.basename(report_file)}"
                    self.summaries[tool_name] = parser.get_summary()
                    
                except Exception as e:
                    print(f"Error parsing {report_file}: {e}")
    
    def generate_report(self, output_dir: str = "outputs") -> str:
        """Генерирует итоговый HTML отчет."""
        generator = HTMLGenerator()
        
        # Добавляем все issues и сводки
        generator.issues = self.all_issues
        generator.summaries = self.summaries
        
        output_path = os.path.join(output_dir, "comprehensive_devsecops_report.html")
        report_path = generator.generate(output_path)
        
        print(f"HTML report generated: {report_path}")
        return report_path
    
    def send_notifications(self, report_path: str, notification_config: str = "config/notification_config.yaml"):
        """Отправляет уведомления о результатах."""
        try:
            with open(notification_config, 'r') as f:
                notify_config = yaml.safe_load(f)
        except FileNotFoundError:
            print("Notification config not found. Skipping notifications.")
            return
        
        notifier = Notifier(notify_config)
        
        # Подготавливаем сообщение
        total_issues = len(self.all_issues)
        critical_issues = len([i for i in self.all_issues if i.get('severity') in ['critical', 'high']])
        
        message = f"""
🔒 *DevSecOps Security Report*

*Summary:*
• Total Issues: {total_issues}
• Critical/High Issues: {critical_issues}
• Tools Processed: {len(self.summaries)}

{'🚨 CRITICAL: High severity issues found!' if critical_issues > 0 else '✅ All checks passed!'}

Detailed report: {report_path}
        """
        
        # Отправка в Slack
        if notify_config.get('slack', {}).get('enabled', False):
            notifier.send_slack(message)
        
        # Отправка в Telegram
        if notify_config.get('telegram', {}).get('enabled', False):
            notifier.send_telegram(message)
        
        # Отправка email
        if notify_config.get('email', {}).get('enabled', False):
            email_subject = "DevSecOps Security Report"
            if critical_issues > 0:
                email_subject = f"🚨 {email_subject} - {critical_issues} Critical Issues Found!"
            
            with open(report_path, 'r') as f:
                html_content = f.read()
            
            notifier.send_email(
                email_subject,
                html_content,
                notify_config.get('email', {}).get('recipients', [])
            )

def main():
    """Основная функция."""
    parser = argparse.ArgumentParser(description='Universal DevSecOps Reporter')
    parser.add_argument('--reports-dir', default='.', help='Directory to search for reports')
    parser.add_argument('--output-dir', default='outputs', help='Output directory for generated reports')
    parser.add_argument('--config', default='config/tool_config.yaml', help='Path to tool config')
    parser.add_argument('--notify-config', default='config/notification_config.yaml', help='Path to notification config')
    parser.add_argument('--send-notifications', action='store_true', help='Send notifications')
    
    args = parser.parse_args()
    
    # Инициализация репортера
    reporter = UniversalReporter(args.config)
    
    # Обнаружение отчетов
    print("Discovering reports...")
    reports = reporter.discover_reports(args.reports_dir)
    
    if not any(reports.values()):
        print("No reports found!")
        return
    
    # Парсинг отчетов
    print("Parsing reports...")
    reporter.parse_reports(reports)
    
    # Генерация отчета
    print("Generating comprehensive report...")
    report_path = reporter.generate_report(args.output_dir)
    
    # Отправка уведомлений
    if args.send_notifications:
        print("Sending notifications...")
        reporter.send_notifications(report_path, args.notify_config)
    
    print("Done!")

if __name__ == "__main__":
    main()