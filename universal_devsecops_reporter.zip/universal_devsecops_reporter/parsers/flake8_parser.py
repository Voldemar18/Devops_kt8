from .base_parser import BaseParser
import json

class Flake8Parser(BaseParser):
    """Парсер для отчетов Flake8."""
    
    def parse(self):
        data = self._read_file()
        
        # Flake8 JSON format
        if isinstance(data, list):
            for error in data:
                self.issues.append({
                    'tool': 'Flake8',
                    'type': 'Linter',
                    'severity': self._map_severity(error.get('code', '')),
                    'filename': error.get('filename', ''),
                    'line_number': error.get('line_number', 0),
                    'column': error.get('column_number', 0),
                    'message': error.get('text', ''),
                    'code': error.get('code', ''),
                    'category': 'code_quality'
                })
        # Text format fallback
        elif isinstance(data, str):
            for line in data.split('\n'):
                if line.strip() and ':' in line:
                    parts = line.split(':', 3)
                    if len(parts) >= 4:
                        filename, line_num, col, message = parts[0], parts[1], parts[2], parts[3]
                        self.issues.append({
                            'tool': 'Flake8',
                            'type': 'Linter',
                            'severity': self._map_severity(message),
                            'filename': filename.strip(),
                            'line_number': int(line_num) if line_num.isdigit() else 0,
                            'column': int(col) if col.isdigit() else 0,
                            'message': message.strip(),
                            'category': 'code_quality'
                        })
        
        # Сводка
        self.summary = {
            'total_issues': len(self.issues),
            'errors': len([i for i in self.issues if i['severity'] == 'error']),
            'warnings': len([i for i in self.issues if i['severity'] == 'warning']),
            'style_issues': len([i for i in self.issues if i['severity'] == 'info'])
        }
    
    def _map_severity(self, code: str) -> str:
        """Маппинг кодов Flake8 на уровни серьезности."""
        if code.startswith('E9') or code.startswith('F'):
            return 'error'
        elif code.startswith('E') or code.startswith('W'):
            return 'warning'
        else:
            return 'info'