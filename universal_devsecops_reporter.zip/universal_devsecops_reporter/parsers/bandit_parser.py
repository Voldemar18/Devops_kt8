from .base_parser import BaseParser

class BanditParser(BaseParser):
    """Парсер для отчетов Bandit."""
    
    def parse(self):
        data = self._read_file()
        
        # Парсинг результатов
        for result in data.get('results', []):
            self.issues.append({
                'tool': 'Bandit',
                'type': 'SAST',
                'severity': result.get('issue_severity', 'LOW').lower(),
                'confidence': result.get('issue_confidence', 'LOW').lower(),
                'filename': result.get('filename', ''),
                'line_number': result.get('line_number', 0),
                'issue_text': result.get('issue_text', ''),
                'test_id': result.get('test_id', ''),
                'category': 'security'
            })
        
        # Сводка из метрик
        metrics = data.get('metrics', {})
        total_issues = len(self.issues)
        
        self.summary = {
            'total_issues': total_issues,
            'high_severity': len([i for i in self.issues if i['severity'] == 'high']),
            'medium_severity': len([i for i in self.issues if i['severity'] == 'medium']),
            'low_severity': len([i for i in self.issues if i['severity'] == 'low'])
        }