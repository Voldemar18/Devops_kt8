from .base_parser import BaseParser

class SonarQubeParser(BaseParser):
    """Парсер для отчетов SonarQube."""
    
    def parse(self):
        data = self._read_file()
        
        # Парсинг issues
        if 'issues' in data:
            for issue in data['issues']:
                self.issues.append({
                    'tool': 'SonarQube',
                    'type': 'SAST',
                    'severity': issue.get('severity', 'INFO').lower(),
                    'component': issue.get('component', ''),
                    'message': issue.get('message', ''),
                    'line': issue.get('line', 0),
                    'rule': issue.get('rule', ''),
                    'category': 'security' if 'security' in issue.get('type', '').lower() else 'quality'
                })
        
        # Парсинг метрик
        if 'metrics' in data:
            for metric in data['metrics']:
                self.metrics[metric['key']] = metric['value']
        
        # Сводка
        self.summary = {
            'total_issues': len(self.issues),
            'critical_issues': len([i for i in self.issues if i['severity'] == 'critical']),
            'high_issues': len([i for i in self.issues if i['severity'] == 'major']),
            'coverage': self.metrics.get('coverage', 0),
            'code_smells': self.metrics.get('code_smells', 0),
            'vulnerabilities': self.metrics.get('vulnerabilities', 0)
        }