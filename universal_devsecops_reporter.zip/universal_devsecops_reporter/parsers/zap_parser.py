from .base_parser import BaseParser

class ZAPParser(BaseParser):
    """Парсер для отчетов OWASP ZAP."""
    
    def parse(self):
        data = self._read_file()
        
        # Парсинг сайтов и алертов
        for site in data.get('site', []):
            for alert in site.get('alerts', []):
                self.issues.append({
                    'tool': 'OWASP ZAP',
                    'type': 'DAST',
                    'severity': alert.get('riskcode', 0),  # 0: Info, 1: Low, 2: Medium, 3: High
                    'name': alert.get('name', ''),
                    'description': alert.get('desc', ''),
                    'url': site.get('@name', ''),
                    'solution': alert.get('solution', ''),
                    'category': 'security'
                })
        
        # Сводка
        risk_counts = {'0': 0, '1': 0, '2': 0, '3': 0}
        for issue in self.issues:
            risk_counts[str(issue['severity'])] += 1
        
        self.summary = {
            'total_alerts': len(self.issues),
            'high_risk': risk_counts['3'],
            'medium_risk': risk_counts['2'],
            'low_risk': risk_counts['1'],
            'informational': risk_counts['0']
        }