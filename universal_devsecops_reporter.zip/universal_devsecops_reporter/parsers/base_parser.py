from abc import ABC, abstractmethod
from typing import Dict, List, Any
import json
import xml.etree.ElementTree as ET

class BaseParser(ABC):
    """Абстрактный базовый класс для всех парсеров отчетов."""
    
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.issues = []
        self.metrics = {}
        self.summary = {}
    
    @abstractmethod
    def parse(self):
        """Основной метод для парсинга отчета."""
        pass
    
    def _read_file(self):
        """Утилита для чтения файла с автоматическим определением формата."""
        with open(self.file_path, 'r', encoding='utf-8') as f:
            if self.file_path.endswith('.json'):
                return json.load(f)
            elif self.file_path.endswith('.xml'):
                tree = ET.parse(self.file_path)
                return tree.getroot()
            else:
                # Для текстовых форматов
                return f.read()
    
    def get_issues(self) -> List[Dict[str, Any]]:
        """Возвращает список найденных проблем."""
        return self.issues
    
    def get_metrics(self) -> Dict[str, Any]:
        """Возвращает метрики."""
        return self.metrics
    
    def get_summary(self) -> Dict[str, Any]:
        """Возвращает сводку."""
        return self.summary