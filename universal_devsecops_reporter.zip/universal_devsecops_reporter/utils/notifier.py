import smtplib
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, Any
import json

class Notifier:
    """Класс для отправки уведомлений через различные каналы."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
    
    def send_email(self, subject: str, html_content: str, to_emails: list):
        """Отправка email через SMTP."""
        try:
            smtp_config = self.config.get('smtp', {})
            msg = MIMEMultipart()
            msg['From'] = smtp_config.get('from_email')
            msg['To'] = ', '.join(to_emails)
            msg['Subject'] = subject
            
            msg.attach(MIMEText(html_content, 'html'))
            
            with smtplib.SMTP(smtp_config.get('host'), smtp_config.get('port')) as server:
                if smtp_config.get('use_tls'):
                    server.starttls()
                if smtp_config.get('username'):
                    server.login(smtp_config.get('username'), smtp_config.get('password'))
                server.send_message(msg)
            
            print(f"Email sent successfully to {to_emails}")
        except Exception as e:
            print(f"Failed to send email: {e}")
    
    def send_slack(self, message: str, webhook_url: str = None):
        """Отправка сообщения в Slack."""
        try:
            url = webhook_url or self.config.get('slack', {}).get('webhook_url')
            if not url:
                print("Slack webhook URL not configured")
                return
            
            payload = {
                "text": message,
                "username": "DevSecOps Reporter",
                "icon_emoji": ":shield:"
            }
            
            response = requests.post(url, json=payload)
            response.raise_for_status()
            print("Slack message sent successfully")
        except Exception as e:
            print(f"Failed to send Slack message: {e}")
    
    def send_telegram(self, message: str, chat_id: str = None, bot_token: str = None):
        """Отправка сообщения в Telegram."""
        try:
            token = bot_token or self.config.get('telegram', {}).get('bot_token')
            chat = chat_id or self.config.get('telegram', {}).get('chat_id')
            
            if not token or not chat:
                print("Telegram bot token or chat ID not configured")
                return
            
            url = f"https://api.telegram.org/bot{token}/sendMessage"
            payload = {
                "chat_id": chat,
                "text": message,
                "parse_mode": "HTML"
            }
            
            response = requests.post(url, json=payload)
            response.raise_for_status()
            print("Telegram message sent successfully")
        except Exception as e:
            print(f"Failed to send Telegram message: {e}")