from typing import List, Dict, Any
import os
from datetime import datetime

class HTMLGenerator:
    """Генератор HTML отчетов."""
    
    def __init__(self, template_path: str = "templates/report_template.html"):
        self.template_path = template_path
        self.issues = []
        self.summaries = {}
    
    def add_issues(self, issues: List[Dict[str, Any]]):
        """Добавляет проблемы в отчет."""
        self.issues.extend(issues)
    
    def add_summary(self, tool_name: str, summary: Dict[str, Any]):
        """Добавляет сводку по инструменту."""
        self.summaries[tool_name] = summary
    
    def generate(self, output_path: str = "outputs/security_report.html"):
        """Генерирует финальный HTML отчет."""
        
        # Чтение шаблона
        with open(self.template_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        # Замена плейсхолдеров
        html_content = html_content.replace('{{GENERATION_DATE}}', datetime.now().isoformat())
        html_content = html_content.replace('{{SUMMARY_SECTION}}', self._generate_summary_section())
        html_content = html_content.replace('{{ISSUES_SECTION}}', self._generate_issues_section())
        
        # Создание директории если нужно
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        # Сохранение отчета
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return output_path
    
    def _generate_summary_section(self) -> str:
        """Генерирует секцию сводки."""
        summary_html = '<div class="summary-section">'
        
        for tool, summary in self.summaries.items():
            summary_html += f'''
            <div class="tool-summary">
                <h3>{tool}</h3>
                <div class="metrics">
            '''
            
            for key, value in summary.items():
                summary_html += f'<div class="metric"><span class="metric-name">{key}:</span> <span class="metric-value">{value}</span></div>'
            
            summary_html += '</div></div>'
        
        summary_html += '</div>'
        return summary_html
    
    def _generate_issues_section(self) -> str:
        """Генерирует секцию с проблемами."""
        if not self.issues:
            return '<p>No issues found. Great job!</p>'
        
        issues_html = '''
        <table class="issues-table">
            <thead>
                <tr>
                    <th>Tool</th>
                    <th>Severity</th>
                    <th>Category</th>
                    <th>Message</th>
                    <th>Location</th>
                </tr>
            </thead>
            <tbody>
        '''
        
        for issue in self.issues:
            severity_class = f"severity-{issue.get('severity', 'info')}"
            issues_html += f'''
            <tr class="{severity_class}">
                <td>{issue.get('tool', 'Unknown')}</td>
                <td><span class="severity-badge {severity_class}">{issue.get('severity', 'info')}</span></td>
                <td>{issue.get('category', 'unknown')}</td>
                <td>{issue.get('message', issue.get('issue_text', issue.get('description', 'No description')))}</td>
                <td>{issue.get('filename', issue.get('url', issue.get('component', 'N/A')))}:{issue.get('line', issue.get('line_number', 'N/A'))}</td>
            </tr>
            '''
        
        issues_html += '</tbody></table>'
        return issues_html